def v_print(verbose=False, msg=""):
    print(msg)
